# vue_demo

## 安装依赖
```
yarn install
```

### 启动服务
```
yarn serve
```

### 打包
```
yarn build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).


#本项目是学习 总结的一个小demo 基于vue-cli4版本 vue2版本 element
解决axios封装 以及跨域问题 以及环境变量配置的问题 

#####一个个人学习的小demo


### 安装依赖
npm install 
### 运行
npm run dev

https://github.com/gzm-gzm/frame/raw/master[分支名称]/screenshots/image.png


